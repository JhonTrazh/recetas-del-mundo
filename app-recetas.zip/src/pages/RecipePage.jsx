import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getMealById } from '../services/api';

function RecipePage() {
  const { id } = useParams();
  const [meal, setMeal] = useState(null);

  useEffect(() => {
    getMealById(id).then(data => setMeal(data.meals[0]));
  }, [id]);

  if (!meal) return <p>Cargando...</p>;

  const ingredients = Object.keys(meal)
    .filter(key => key.startsWith('strIngredient') && meal[key])
    .map(key => `${meal[key]} - ${meal['strMeasure' + key.slice(13)]}`);

  return (
    <div className="detail">
      <h1>{meal.strMeal}</h1>
      <p><strong>Categoría:</strong> {meal.strCategory}</p>
      <p><strong>Área:</strong> {meal.strArea}</p>
      <img src={meal.strMealThumb} alt={meal.strMeal} />
      <h3>Ingredientes:</h3>
      <ul>{ingredients.map((ing, i) => <li key={i}>{ing}</li>)}</ul>
      <h3>Instrucciones:</h3>
      <p>{meal.strInstructions}</p>
      {meal.strYoutube && (
        <iframe
          width="100%"
          height="315"
          src={`https://www.youtube.com/embed/${meal.strYoutube.split('=')[1]}`}
          title="YouTube video"
          allowFullScreen
        ></iframe>
      )}
    </div>
  );
}

export default RecipePage;