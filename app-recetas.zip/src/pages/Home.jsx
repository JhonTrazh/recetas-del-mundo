import { useEffect, useState } from 'react';
import { getMealsByCategory, searchMealsByName } from '../services/api';
import SearchBar from '../components/SearchBar';
import RecipeList from '../components/RecipeList';

function Home() {
  const [meals, setMeals] = useState([]);
  const [query, setQuery] = useState('');

  useEffect(() => {
    if (query.length === 0) {
      getMealsByCategory('Dessert').then(data => setMeals(data.meals));
    } else {
      searchMealsByName(query).then(data => setMeals(data.meals || []));
    }
  }, [query]);

  return (
    <div className="container">
      <SearchBar setQuery={setQuery} />
      <RecipeList meals={meals} />
    </div>
  );
}

export default Home;