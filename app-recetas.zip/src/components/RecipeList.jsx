import RecipeCard from './RecipeCard';

function RecipeList({ meals }) {
  if (!meals || meals.length === 0) return <p>No se encontraron recetas.</p>;

  return (
    <div className="grid">
      {meals.map(meal => (
        <RecipeCard key={meal.idMeal} meal={meal} />
      ))}
    </div>
  );
}
export default RecipeList;