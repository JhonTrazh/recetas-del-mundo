function SearchBar({ setQuery }) {
  return (
    <input
      type="text"
      placeholder="Buscar receta..."
      onChange={(e) => setQuery(e.target.value)}
      className="search-input"
    />
  );
}
export default SearchBar;