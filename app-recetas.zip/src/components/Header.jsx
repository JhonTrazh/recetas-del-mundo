function Header() {
  return (
    <header>
      <h1>App de Recetas</h1>
    </header>
  );
}
export default Header;