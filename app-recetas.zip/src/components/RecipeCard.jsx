import { Link } from 'react-router-dom';

function RecipeCard({ meal }) {
  return (
    <div className="card">
      <img src={meal.strMealThumb} alt={meal.strMeal} />
      <h3>{meal.strMeal}</h3>
      <Link to={`/recipe/${meal.idMeal}`}>Ver detalles</Link>
    </div>
  );
}
export default RecipeCard;