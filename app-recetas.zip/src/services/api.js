const BASE_URL = 'https://www.themealdb.com/api/json/v1/1';

export const getMealsByCategory = async (category = 'Dessert') => {
  const res = await fetch(`${BASE_URL}/filter.php?c=${category}`);
  return res.json();
};

export const searchMealsByName = async (name) => {
  const res = await fetch(`${BASE_URL}/search.php?s=${name}`);
  return res.json();
};

export const getMealById = async (id) => {
  const res = await fetch(`${BASE_URL}/lookup.php?i=${id}`);
  return res.json();
};